package com.serifgungor.customlistview.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.customlistview.Adapter.YazilimDilleriAdapter;
import com.serifgungor.customlistview.Model.YazilimDilleri;
import com.serifgungor.customlistview.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    YazilimDilleriAdapter adapter;
    ArrayList<YazilimDilleri> yazilimDilleriArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        yazilimDilleriArrayList.add(new YazilimDilleri("Java","Java Açıklaması",R.drawable.java));
        yazilimDilleriArrayList.add(new YazilimDilleri("PHP","Java Açıklaması",R.drawable.php));
        yazilimDilleriArrayList.add(new YazilimDilleri("Swift","Java Açıklaması",R.drawable.swift));
        yazilimDilleriArrayList.add(new YazilimDilleri("Python","Java Açıklaması",R.drawable.python));
        yazilimDilleriArrayList.add(new YazilimDilleri("C#","Java Açıklaması",R.drawable.csharp));
        yazilimDilleriArrayList.add(new YazilimDilleri("JavaScript","Java Açıklaması",R.drawable.javascript));
        yazilimDilleriArrayList.add(new YazilimDilleri("Kotlin","Java Açıklaması",R.drawable.kotlin));
        yazilimDilleriArrayList.add(new YazilimDilleri("C++","Java Açıklaması",R.drawable.cplusplus));


        adapter = new YazilimDilleriAdapter(getApplicationContext(),yazilimDilleriArrayList);
        listView.setAdapter(adapter);

    }
}
