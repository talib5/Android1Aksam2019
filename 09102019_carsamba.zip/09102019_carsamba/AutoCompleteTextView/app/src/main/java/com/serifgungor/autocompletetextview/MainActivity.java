package com.serifgungor.autocompletetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView acTv;
    MultiAutoCompleteTextView macTv;

    ArrayList<String> sehirler = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sehirler.add("Ankara");
        sehirler.add("Antalya");
        sehirler.add("Kocaeli");
        sehirler.add("Konya");
        sehirler.add("Sivas");
        sehirler.add("Sinop");

        arrayAdapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_dropdown_item_1line,
                sehirler
        );

        acTv = findViewById(R.id.acTv);
        acTv.setAdapter(arrayAdapter);
        acTv.setThreshold(3);

        macTv = findViewById(R.id.macTv);
        macTv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        macTv.setAdapter(arrayAdapter);



    }
}
