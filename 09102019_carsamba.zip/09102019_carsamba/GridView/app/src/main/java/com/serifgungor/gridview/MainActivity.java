package com.serifgungor.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    ArrayAdapter<String> adapter;
    ArrayList<String> liste;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = findViewById(R.id.gridView);

        liste = new ArrayList<>();
        liste.add("Elma");
        liste.add("Armut");
        liste.add("Karpuz");
        liste.add("Kiraz");
        liste.add("Nar");
        liste.add("Kivi");

        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,liste);

        gridView.setAdapter(adapter);
        gridView.setNumColumns(2);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        "YAZI:"+liste.get(position),
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

    }
}
