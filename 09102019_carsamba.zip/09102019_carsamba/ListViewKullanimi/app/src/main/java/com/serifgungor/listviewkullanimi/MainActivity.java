package com.serifgungor.listviewkullanimi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayAdapter<String> diller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ArrayList<String> yazilimDilleri = new ArrayList<>();
        yazilimDilleri.add("PHP");
        yazilimDilleri.add("Java");
        yazilimDilleri.add("C#");
        yazilimDilleri.add("Python");
        yazilimDilleri.add("C++");
        yazilimDilleri.add("C");
        yazilimDilleri.add("Objective C");
        yazilimDilleri.add("Swift");
        yazilimDilleri.add("JavaScript");

        diller = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,yazilimDilleri);
        listView = findViewById(R.id.listView);
        listView.setAdapter(diller);

        // LİSTVİEW NESNESİNİN BİR SATIRINA TIKLAMA OLAYI
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        ""+yazilimDilleri.get(position),
                        Toast.LENGTH_LONG
                ).show();
            }
        });


       listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
           @Override
           public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {


               final AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
               adb.setTitle(yazilimDilleri.get(position));
               adb.setMessage("Burası açıklama alanıdır");
               /*
               adb.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {

                   }
               });
               adb.setNegativeButton("Hayır",null);
               */

               adb.setPositiveButton("Kapat", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {
                       adb.setOnCancelListener(new DialogInterface.OnCancelListener() {
                           @Override
                           public void onCancel(DialogInterface dialog) {
                               dialog.dismiss();
                           }
                       });
                   }
               });
               adb.setCancelable(false);
               adb.create();
               adb.show();


               return false;
           }
       });



    }
}
