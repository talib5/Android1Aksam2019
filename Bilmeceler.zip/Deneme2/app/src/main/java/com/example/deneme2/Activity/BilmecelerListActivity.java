package com.example.deneme2.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.deneme2.Adapter.BilmeceAdapter;
import com.example.deneme2.Helper.DatabaseHelper;
import com.example.deneme2.Model.Bilmece;
import com.example.deneme2.Model.Kategori;
import com.example.deneme2.R;

import java.io.IOException;
import java.util.ArrayList;

public class BilmecelerListActivity extends AppCompatActivity {

    ListView listViewBilmeceler;
    ArrayList<Bilmece> bilmeceler = new ArrayList<>();
    BilmeceAdapter adapter;

    SQLiteDatabase database;
    DatabaseHelper dbHelper;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilmeceler_list);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getBaslik());
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            database = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }


        listViewBilmeceler = findViewById(R.id.listViewBilmeceler);

        c = database.rawQuery("select * from bilmeceler where kategori_id="+kategori.getId(),null);
        while (c.moveToNext()){
            bilmeceler.add(new Bilmece(
                    c.getInt(c.getColumnIndex("id")),
                    1,
                    c.getString(c.getColumnIndex("bilmece")),
                    c.getString(c.getColumnIndex("cevap"))
            ));
        }
        /*
        Cursor sınıfı select sorgusundan dönen tüm satırları okuyabilmek için kullanılır.
        c.moveToNext() metodu her satırı tek tek gezip yeni bir satır varsa true,yoksa false döner.

        c.getInt metodu kolon indisini bildiğimiz bir integer değeri döndürebilmek için kullanılır.
        c.getString metodu kolon indisini bildiğimiz bir string değeri döndürebilmek için kullanılır.
        c.getColumnIndex ise, belirttiğimiz bir kolon ismine ait indisi döner.

         */


        /*
        for (int i=0; i<20; i++){
            bilmeceler.add(new Bilmece(i,kategori.getId(),"Başlık "+i,"Yanıt "+i));
        }
         */

        adapter = new BilmeceAdapter(BilmecelerListActivity.this,bilmeceler,database);
        listViewBilmeceler.setAdapter(adapter);


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish(); //Bulunduğum sayfayı kapattım
        }
        return super.onOptionsItemSelected(item);
    }
}
