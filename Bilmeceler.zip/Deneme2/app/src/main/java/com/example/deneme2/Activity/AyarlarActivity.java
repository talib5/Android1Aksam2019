package com.example.deneme2.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.example.deneme2.Helper.DatabaseHelper;
import com.example.deneme2.R;

import java.io.IOException;
import java.util.ArrayList;

public class AyarlarActivity extends AppCompatActivity {
    Spinner spinner;
    ArrayList<String> kategoriBasliklari = new ArrayList<>();

    SQLiteDatabase sqLiteDatabase;
    DatabaseHelper databaseHelper;
    ArrayAdapter<String> arrayAdapter;

    Switch swListeModu;
    SharedPreferences sp;
    SharedPreferences.Editor spe;

    ListView listViewFavoriler;
    ArrayList<String> favoriBasliklari = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayarlar);

        spinner = findViewById(R.id.spinnerKategori);
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        swListeModu = findViewById(R.id.swListeModu);

        try {
            databaseHelper = new DatabaseHelper(getApplicationContext());
            sqLiteDatabase = databaseHelper.getReadableDatabase();

            Cursor c = sqLiteDatabase.rawQuery("select * from kategoriler",null);
            while (c.moveToNext()){
                kategoriBasliklari.add(c.getString(c.getColumnIndex("baslik")));
            }

            Cursor c2 = sqLiteDatabase.rawQuery("select * from bilmeceler where fav=1",null);
            if(c2.getCount()>0){
                while (c2.moveToNext()){
                    favoriBasliklari.add(c.getString(c.getColumnIndex("baslik")));
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


        listViewFavoriler = findViewById(R.id.listViewFavoriler);
        arrayAdapter2 = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,favoriBasliklari);
        listViewFavoriler.setAdapter(arrayAdapter2);



        if(sp.getInt("liste_durum",0)==1){
            swListeModu.setChecked(true);
        }else{
            swListeModu.setChecked(false);
        }


        swListeModu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    spe.putInt("liste_durum",1);
                }else{
                    spe.putInt("liste_durum",0);
                }
                spe.commit();
            }
        });





        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,kategoriBasliklari);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),kategoriBasliklari.get(position),Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
}
