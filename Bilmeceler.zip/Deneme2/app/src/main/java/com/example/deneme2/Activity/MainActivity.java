package com.example.deneme2.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.deneme2.Adapter.KategoriAdapter;
import com.example.deneme2.Model.Kategori;
import com.example.deneme2.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView kategoriler;
    KategoriAdapter kategoriAdapter;
    ArrayList<Kategori> kategoriArrayList;

    SharedPreferences sp;
    SharedPreferences.Editor spe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Bilmeceler"); //Toolbarın başlığını değiştirir.
        kategoriler = findViewById(R.id.listViewKategoriler);
        kategoriArrayList = new ArrayList<>();
        kategoriArrayList.add(new Kategori(1,"\uD83D\uDE00","Klasik",50));
        kategoriArrayList.add(new Kategori(2,"\uD83D\uDE00","İlginç",40));
        kategoriArrayList.add(new Kategori(3,"\uD83D\uDE00","Çocuk",12));
        kategoriArrayList.add(new Kategori(4,"\uD83D\uDE00","Komik",75));
        //int id, String emoji, String baslik, int kategoriSayi


        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        kategoriAdapter = new KategoriAdapter(getApplicationContext(),kategoriArrayList);
        kategoriler.setAdapter(kategoriAdapter);

        kategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        kategoriArrayList.get(position).getBaslik(),
                        Toast.LENGTH_LONG
                ).show();

                Intent intent = null;
                if(sp.getInt("liste_durum",0)==1){
                    intent = new Intent(getApplicationContext(),BilmecelerListActivity.class);
                }else{
                    intent = new Intent(getApplicationContext(),BilmecelerActivity.class);
                }

                intent.putExtra("kategori",kategoriArrayList.get(position));
                startActivity(intent);

            }
        });



        /*
1. aşama - ListView üret
2. aşama - satır görüntüsü layout'ı üret
3. aşama - Model sınıfı üret (OOP Kapsülleme işlemi)
4. aşama - BaseAdapter sınıfı üret
5. aşama - İlgili activity sayfasında arraylist üret ve içini doldur.
6. aşama - İlgili activity sayfasında baseadapter'i listview'e bağla.
         */
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Menü oluşturmak için kullanılır
        getMenuInflater().inflate(R.menu.menu_main,menu); //menu_main.xml dosyasını toolbar'da gösterir.
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //Menu Item'a tıklama olayını yakalamak için kullanılır.

        if(item.getItemId()==R.id.id_ayarlar){
            startActivity(new Intent(getApplicationContext(),AyarlarActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
