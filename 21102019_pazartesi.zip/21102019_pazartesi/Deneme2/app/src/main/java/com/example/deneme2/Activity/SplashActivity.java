package com.example.deneme2.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.deneme2.R;

public class SplashActivity extends AppCompatActivity {

    private class Beklet extends Thread{

        @Override
        public void run() {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent); //MainActivity sayfasını açar
            finish(); //Bulunduğum sayfayı kapatır.
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Beklet().start();
    }
}
