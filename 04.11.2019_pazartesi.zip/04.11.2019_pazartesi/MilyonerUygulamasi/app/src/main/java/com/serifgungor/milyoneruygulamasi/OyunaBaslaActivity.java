package com.serifgungor.milyoneruygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OyunaBaslaActivity extends AppCompatActivity {

    LinearLayout linearLayoutSeviyeler;
    Button btnYanitA,btnYanitB,btnYanitC,btnYanitD;
    ImageView ivYariYariya,ivTelefon,ivSeyirci;
    TextView tvSoru,tvSayac;

    public void seviyeleriGetir(String[] seviyeler){
        for (int i=0; i<12; i++){
            TextView tvSeviye = new TextView(getApplicationContext());
            tvSeviye.setText(seviyeler[i]);
            tvSeviye.setId(i);
            tvSeviye.setTextColor(Color.parseColor("#ffffff"));
            tvSeviye.setTextSize(20);
            linearLayoutSeviyeler.addView(tvSeviye);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuna_basla);

        tvSoru = findViewById(R.id.tvSoru);
        tvSayac = findViewById(R.id.tvSayac);
        linearLayoutSeviyeler = findViewById(R.id.linearLayoutSeviyeler);
        btnYanitA = findViewById(R.id.btnYanitA);
        btnYanitB = findViewById(R.id.btnYanitB);
        btnYanitC = findViewById(R.id.btnYanitC);
        btnYanitD = findViewById(R.id.btnYanitD);
        ivYariYariya = findViewById(R.id.yariYariyaJoker);
        ivTelefon = findViewById(R.id.telefonJoker);
        ivSeyirci = findViewById(R.id.seyirciJoker);

        String[] seviyeler = {"500TL","1000TL","2000TL","3000TL","5000TL","7500TL","15000TL","30000TL","60000TL","125000","250000","1000000TL"};
        seviyeleriGetir(seviyeler);

    }
}
