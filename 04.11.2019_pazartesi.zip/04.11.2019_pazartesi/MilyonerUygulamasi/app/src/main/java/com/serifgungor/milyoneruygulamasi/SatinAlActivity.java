package com.serifgungor.milyoneruygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SatinAlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_satin_al);
    }
}
