package com.serifgungor.milyoneruygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btnOyunaBasla,btnBasarilar,btnSkorlar,btnSatinAl,btnCikis;
    ImageView ivSound;
    int sayi = 0;
    SharedPreferences sp;
    SharedPreferences.Editor spe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().hide();

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        btnBasarilar = findViewById(R.id.btnBasarilar);
        btnOyunaBasla = findViewById(R.id.btnOyunaBasla);
        btnSkorlar = findViewById(R.id.btnSkorlar);
        btnSatinAl = findViewById(R.id.btnSatinAl);
        btnCikis = findViewById(R.id.btnCikis);
        ivSound = findViewById(R.id.ivSound);

        sayi = sp.getInt("sound",1);
        if(sp.getInt("sound",1)==0){
            ivSound.setImageResource(R.drawable.ic_on);
        }else if(sp.getInt("sound",1)==1){
            ivSound.setImageResource(R.drawable.ic_off);
        }

        ivSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(sayi==0){ // Ses açıksa
                   //Sesi kapat
                   sayi=1;
                   ivSound.setImageResource(R.drawable.ic_off);
               }else if(sayi==1){ //Ses kapalıysa
                   //Sesi aç
                   sayi=0;
                   ivSound.setImageResource(R.drawable.ic_on);
               }
               spe.putInt("sound",sayi);
               spe.commit();
            }
        });

        btnCikis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSatinAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),SatinAlActivity.class));
            }
        });

        btnSkorlar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),SkorlarActivity.class));
            }
        });

        btnOyunaBasla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),OyunaBaslaActivity.class));
            }
        });

        btnBasarilar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),BasarilarActivity.class));
            }
        });

    }
}
