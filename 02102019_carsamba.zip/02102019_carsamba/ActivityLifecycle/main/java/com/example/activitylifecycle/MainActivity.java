package com.example.activitylifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("UYGULAMA_LOGU","onCreate Metodu çalıştı");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("UYGULAMA_LOGU","onRestart Metodu çalıştı");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("UYGULAMA_LOGU","onStart Metodu çalıştı");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("UYGULAMA_LOGU","onStop Metodu çalıştı");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("UYGULAMA_LOGU","onDestroy Metodu çalıştı");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("UYGULAMA_LOGU","onPause Metodu çalıştı");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("UYGULAMA_LOGU","onResume Metodu çalıştı");
    }
}
