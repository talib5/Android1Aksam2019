package com.serifgungor.milyoneruygulamasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.serifgungor.milyoneruygulamasi.Model.Soru;
import com.serifgungor.milyoneruygulamasi.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;

public class OyunaBaslaActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onClick(View v) {

    }

    LinearLayout linearLayoutSeviyeler;
    Button btnYanitA,btnYanitB,btnYanitC,btnYanitD,btnOyundanCekil;
    ImageView ivYariYariya,ivTelefon,ivSeyirci;
    TextView tvSoru,tvSayac;

    //AdView adView;
    //private InterstitialAd mInterstitialAd; //Tam sayfa reklam göstermek için kullanılan sınıftır.
    Dialog dialog;
    MediaPlayer mySound;

    SharedPreferences sp;
    SharedPreferences.Editor spe;
    int index = 0;
    String tarih;
    int telefon_jokeri = 0;
    int seyirci_jokeri = 0;
    int yariyariya_jokeri = 0;
    int oyundan_cekildimi = 0;
    String toplam_kazanc = "";
    int oyunda_gecen_sure = 0;

    ArrayList<Soru> sorular;
    Timer timerGeriSayac,timerOyundaGecenSure;


    public void reklamGetir(){
        //Her 3 yanlış yanıtta bir oyunu sıfırlayacağımızda bu metodu çağırırız.
        //Eğer değer 3 ise reklam gösterir ve sayıyı yeniden sıfırlar, değil ise hiçbir işlem yapmaz.
        int reklamSayi = sp.getInt("reklamSayi",0);
        if(reklamSayi>2){
            //reklamGoster
            /*
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            if(mInterstitialAd.isLoaded()){ //eğer reklam yüklendiyse
                mInterstitialAd.show(); //Tam sayfa reklamı göster
            }else{
                Log.d("UYARI","Reklam henüz yüklenemedi !");
            }
             */
            spe.putInt("reklamSayi",0);
            spe.commit();
        }
    }




    public void seviyeleriGetir(String[] seviyeler){
        for (int i=0; i<12; i++){
            TextView tvSeviye = new TextView(getApplicationContext());
            tvSeviye.setText(seviyeler[i]);
            tvSeviye.setId(i); //Nesnenin programatik olarak referansına erişebilmek için
            tvSeviye.setTextColor(Color.parseColor("#ffffff")); //Yazının rengini değiştirdik

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,90);
            params.setMargins(0,0,0,20);
            tvSeviye.setLayoutParams(params);
            tvSeviye.setGravity(Gravity.CENTER);

            if(i== 1 || i==6 || i==11){
                tvSeviye.setBackgroundResource(R.drawable.button_style2); //mavi
            }else{
                tvSeviye.setBackgroundResource(R.drawable.button_style1); //turuncu
            }

            tvSeviye.setTextSize(16);
            linearLayoutSeviyeler.addView(tvSeviye);
        }
    }

    public void seviyeleriTemizle(){
        for (int i=0; i<linearLayoutSeviyeler.getChildCount(); i++){
            TextView seviye = (TextView)linearLayoutSeviyeler.getChildAt(i);
            if(i == 1 || i==6 || i==11){
                seviye.setBackgroundResource(R.drawable.button_style2); // baraj sorusu
            }else if(i==0){ // ilk soru seçili gelecek
                //selected
                seviye.setBackgroundResource(R.drawable.button_style3);
            }else{
                seviye.setBackgroundResource(R.drawable.button_style1); // soru seçilmedi
            }
        }
    }

    public void tumButonlariGeriGetir(){
        btnYanitA.setVisibility(View.VISIBLE);
        btnYanitB.setVisibility(View.VISIBLE);
        btnYanitC.setVisibility(View.VISIBLE);
        btnYanitD.setVisibility(View.VISIBLE);
    }

    public ArrayList<Soru> sorulariGetir(){
        ArrayList<Soru> sorular = new ArrayList<>();

        for (int i=0; i<12; i++){
            sorular.add(
                new Soru(
                        i,
                        0,
                        "Soru başlığı"+i,
                        "Yanıt a"+i,
                        "Yanıt b"+i,
                        "Yanıt c"+i,
                        "Yanıt d"+i,
                        "a"
                )
            );
        }

        return sorular;
    }

    public void yenidenOyna(){
        ivSeyirci.setVisibility(View.VISIBLE);//resmi göster
        ivTelefon.setVisibility(View.VISIBLE);
        ivYariYariya.setVisibility(View.VISIBLE);
        index = 0;
        sorular = sorulariGetir();
        soruyuGetir(0);
        //timer.cancel();
        sureyiSay();
        seviyeleriTemizle();
        tarih = new Date().toString();
        telefon_jokeri = 0;
        seyirci_jokeri = 0;
        yariyariya_jokeri = 0;
        oyundan_cekildimi = 0;
        toplam_kazanc = "";
        oyunda_gecen_sure = 0;
        tumButonlariGeriGetir();
        spe.putInt("reklamSayi",sp.getInt("reklamSayi",0) +1);
        spe.commit();
        reklamGetir();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuna_basla);

        this.getSupportActionBar().hide(); //Toolbarı gizledik

        tvSoru = findViewById(R.id.tvSoru);
        tvSayac = findViewById(R.id.tvSayac);
        linearLayoutSeviyeler = findViewById(R.id.linearLayoutSeviyeler);
        btnYanitA = findViewById(R.id.btnYanitA);
        btnYanitB = findViewById(R.id.btnYanitB);
        btnYanitC = findViewById(R.id.btnYanitC);
        btnYanitD = findViewById(R.id.btnYanitD);
        btnOyundanCekil = findViewById(R.id.btnOyundanCekil);
        ivYariYariya = findViewById(R.id.yariYariyaJoker);
        ivTelefon = findViewById(R.id.telefonJoker);
        ivSeyirci = findViewById(R.id.seyirciJoker);

        btnOyundanCekil.setOnClickListener(this);
        btnYanitA.setOnClickListener(this);
        btnYanitB.setOnClickListener(this);
        btnYanitC.setOnClickListener(this);
        btnYanitD.setOnClickListener(this);

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        //MobileAds.initialize(this,"ca-app-pub- ~");
        //mInterstitialAd = new InterstitialAd(this);
        //mInterstitialAd.setAdUnitId("ca-app-pub-");


        String[] seviyeler = {"500TL","1000TL","2000TL","3000TL","5000TL","7500TL","15000TL","30000TL","60000TL","125000","250000","1000000TL"};
        seviyeleriGetir(seviyeler);

    }

    public void soruYanitDogruSes(){
        mySound = MediaPlayer.create(this,R.raw.correct);
        if(!mySound.isPlaying()){
            mySound.start();
        }

    }
    public void soruYanitYanlisSes(){
        mySound = MediaPlayer.create(this,R.raw.lose);
        if(!mySound.isPlaying()){
            mySound.start();
        }
    }
    public void soruOyunaBaslaSes(){
        mySound = MediaPlayer.create(this,R.raw.barajbir);
        if(!mySound.isPlaying()){
            mySound.start();
        }
    }

}
