package com.serifgungor.wallpapers.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.wallpapers.Adapter.KategoriAdapter;
import com.serifgungor.wallpapers.Model.Kategori;
import com.serifgungor.wallpapers.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewKategoriler;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    KategoriAdapter kategoriAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewKategoriler = findViewById(R.id.listViewKategoriler);
        kategoriler.add(new Kategori(1,"Arabalar",R.drawable.car));
        kategoriler.add(new Kategori(2,"Doğa",R.drawable.nature));
        kategoriler.add(new Kategori(3,"Çiçekler",R.drawable.flower));
        kategoriler.add(new Kategori(4,"Hayvanlar",R.drawable.animal));

        kategoriAdapter = new KategoriAdapter(getApplicationContext(),kategoriler);
        listViewKategoriler.setAdapter(kategoriAdapter);
        listViewKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),ResimGosterActivity.class);
                intent.putExtra("kategori_id",kategoriler.get(position).getId());
                startActivity(intent);
            }
        });
    }
}
