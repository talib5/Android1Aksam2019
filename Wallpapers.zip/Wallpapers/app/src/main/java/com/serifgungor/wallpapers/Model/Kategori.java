package com.serifgungor.wallpapers.Model;

public class Kategori {
    private int id;
    private String baslik;
    private int resimId;

    public Kategori() {
    }

    public Kategori(int id, String baslik, int resimId) {
        this.id = id;
        this.baslik = baslik;
        this.resimId = resimId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public int getResimId() {
        return resimId;
    }

    public void setResimId(int resimId) {
        this.resimId = resimId;
    }
}
