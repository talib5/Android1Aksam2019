package com.serifgungor.wallpapers.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.WallpaperManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.serifgungor.wallpapers.Model.Resim;
import com.serifgungor.wallpapers.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class ResimGosterActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnOnceki,btnSonraki,btnRastgele,btnPaylas,btnBackground;
    ImageView ivResim;
    int resimIndex=0;

    ArrayList<Resim> resimler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resim_goster);

        btnOnceki = findViewById(R.id.btnOnceki);
        btnSonraki = findViewById(R.id.btnSonraki);
        btnRastgele = findViewById(R.id.btnRastgele);
        btnPaylas = findViewById(R.id.btnPaylas);
        btnBackground = findViewById(R.id.btnBackground);
        ivResim = findViewById(R.id.ivResim);

        btnOnceki.setOnClickListener(this);
        btnSonraki.setOnClickListener(this);
        btnRastgele.setOnClickListener(this);
        btnPaylas.setOnClickListener(this);
        btnBackground.setOnClickListener(this);


        int kategoriId = getIntent().getIntExtra("kategori_id",1);
        resimler.add(new Resim(1,1,R.drawable.car1));
        resimler.add(new Resim(2,1,R.drawable.car2));
        resimler.add(new Resim(3,1,R.drawable.car3));
        resimler.add(new Resim(4,2,R.drawable.nature1));
        resimler.add(new Resim(5,2,R.drawable.nature2));
        resimler.add(new Resim(6,2,R.drawable.nature3));
        resimler.add(new Resim(7,3,R.drawable.flower1));
        resimler.add(new Resim(8,3,R.drawable.flower2));
        resimler.add(new Resim(9,3,R.drawable.flower3));
        resimler.add(new Resim(10,4,R.drawable.animal1));
        resimler.add(new Resim(11,4,R.drawable.animal2));
        resimler.add(new Resim(12,4,R.drawable.animal3));

        ivResim.setImageResource(resimler.get(0).getResimId());
    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.btnOnceki){
            if(resimIndex>0){
                resimIndex -= 1;
            }
            ivResim.setImageResource(resimler.get(resimIndex).getResimId());
        }else if(v.getId()==R.id.btnSonraki){
            if(resimIndex<resimler.size()){
                resimIndex += 1;
            }
            ivResim.setImageResource(resimler.get(resimIndex).getResimId());
        }else if(v.getId()==R.id.btnRastgele){
            Random rnd = new Random();
            resimIndex = rnd.nextInt(resimler.size());
            ivResim.setImageResource(resimler.get(resimIndex).getResimId());
        }else if(v.getId()==R.id.btnBackground){
            WallpaperManager myWallpaperManager
                    = WallpaperManager.getInstance(getApplicationContext());
            try {
                myWallpaperManager.setResource(resimler.get(resimIndex).getResimId());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else if(v.getId()==R.id.btnPaylas){

        }

    }
}
