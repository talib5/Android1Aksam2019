package com.serifgungor.wallpapers.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.wallpapers.Model.Kategori;
import com.serifgungor.wallpapers.R;

import java.util.ArrayList;

public class KategoriAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Kategori> kategoriler;

    public KategoriAdapter(){
    }
    public KategoriAdapter(Context context,ArrayList<Kategori> kategoriler){
        this.context = context;
        this.kategoriler = kategoriler;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Object getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return kategoriler.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       View view = layoutInflater.inflate(R.layout.kategori_satirgoruntusu,null);

        ImageView ivResim = view.findViewById(R.id.ivKategoriResim);
        TextView tvBaslik = view.findViewById(R.id.tvKategoriBaslik);

        ivResim.setImageResource(kategoriler.get(position).getResimId());
        tvBaslik.setText(kategoriler.get(position).getBaslik());

       return view;
    }
}
