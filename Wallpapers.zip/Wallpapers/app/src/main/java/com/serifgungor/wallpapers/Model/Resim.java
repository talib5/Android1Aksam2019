package com.serifgungor.wallpapers.Model;

public class Resim {
    private int id;
    private int kategoriId;
    private int resimId;

    public Resim() {
    }

    public Resim(int id, int kategoriId, int resimId) {
        this.id = id;
        this.kategoriId = kategoriId;
        this.resimId = resimId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public int getResimId() {
        return resimId;
    }

    public void setResimId(int resimId) {
        this.resimId = resimId;
    }
}
