package com.serifgungor.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etAd,etSoyad,etKullaniciAdi,etSifre,etSifre2,etKullaniciAdi2,etSifreYeni;
    Button btnGiris,btnSifreYenile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etKullaniciAdi = findViewById(R.id.etKullaniciAdi);
        etSifre = findViewById(R.id.etSifre);
        etAd = findViewById(R.id.etAdi);
        etSoyad = findViewById(R.id.etSoyadi);
        etKullaniciAdi2 = findViewById(R.id.etKullaniciAdi2);
        etSifre2 = findViewById(R.id.etSifre2);
        etSifreYeni = findViewById(R.id.etSifreYeni);


        btnGiris = findViewById(R.id.btnGonder);
        btnSifreYenile = findViewById(R.id.btnSifreYenile);
        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etKullaniciAdi2.setText(etKullaniciAdi.getText().toString());
                etSifre2.setText(etSifre.getText().toString());
            }
        });

        btnSifreYenile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!etSifreYeni.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Şifreniz *** olarak değiştirilmiştir.",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
