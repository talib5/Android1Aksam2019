package com.serifgungor.scrollviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    public void onClick(View v) {
        Toast.makeText(getApplicationContext(),"Butona tıklandı",Toast.LENGTH_LONG).show();
    }

    LinearLayout linearLayout;

    // PROGRAMATİK OLARAK NESNE ÜRETME

    public void nesneUret(String nesne,String nesneAdi){

        if("textview".equals(nesne)){
            TextView tv = new TextView(getApplicationContext());
            tv.setText(""+nesneAdi);
            linearLayout.addView(tv);
        }else if("button".equals(nesne)){
            Button btn = new Button(getApplicationContext());
            btn.setOnClickListener(this);
            btn.setText(""+nesneAdi);
            linearLayout.addView(btn);
        }else if("checkbox".equals(nesne)){
            CheckBox chk = new CheckBox(getApplicationContext());
            chk.setText(""+nesneAdi);
            linearLayout.addView(chk);
        }else if("edittext".equals(nesne)){
            EditText et = new EditText(getApplicationContext());
            et.setText(""+nesneAdi);
            linearLayout.addView(et);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.linearLayout);
        nesneUret("button","Buton 1");
        nesneUret("edittext","Yazı 1");
        nesneUret("button","Buton 2");
        nesneUret("edittext","Yazı 2");
        nesneUret("button","Buton 3");
        nesneUret("edittext","Yazı 3");
        nesneUret("button","Buton 4");
        nesneUret("edittext","Yazı 1");



    }

}
