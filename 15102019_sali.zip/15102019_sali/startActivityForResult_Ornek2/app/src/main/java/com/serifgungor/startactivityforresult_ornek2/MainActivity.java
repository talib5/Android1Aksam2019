package com.serifgungor.startactivityforresult_ornek2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnElma,btnKiraz,btnAyva,btnPortakal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAyva = findViewById(R.id.btnAyva);
        btnElma = findViewById(R.id.btnElma);
        btnKiraz = findViewById(R.id.btnKiraz);
        btnPortakal = findViewById(R.id.btnPortakal);

        btnPortakal.setOnClickListener(this);
        btnKiraz.setOnClickListener(this);
        btnElma.setOnClickListener(this);
        btnAyva.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String isim = "";
        Intent intent = new Intent(getApplicationContext(),SonucActivity.class);
        intent.putExtra("isim",isim);
        if(v.getId()==R.id.btnAyva){
            isim = "Ayva";
            startActivityForResult(intent,100);
        }else if(v.getId()==R.id.btnElma){
            isim = "Elma";
            startActivityForResult(intent,200);
        }else if(v.getId()==R.id.btnKiraz){
            isim = "Kiraz";
            startActivityForResult(intent,300);
        }else if(v.getId()==R.id.btnPortakal){
            isim = "Portakal";
            startActivityForResult(intent,400);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode){
            case 100:
                Toast.makeText(getApplicationContext(),"Ayva'dan geldim",Toast.LENGTH_LONG).show();
                break;
            case 200:
                Toast.makeText(getApplicationContext(),"Elma'dan geldim",Toast.LENGTH_LONG).show();
                break;
            case 300:
                Toast.makeText(getApplicationContext(),"Kiraz'dan geldim",Toast.LENGTH_LONG).show();
                break;
            case 400:
                Toast.makeText(getApplicationContext(),"Portakal'dan geldim",Toast.LENGTH_LONG).show();
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
