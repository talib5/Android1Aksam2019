package com.serifgungor.startactivityforresult_ornek2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SonucActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonuc);
    }
}
