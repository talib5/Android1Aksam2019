package com.serifgungor.digeruygulamalaricalistirmak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnWeb,btnSms,btnHarita,btnEmail,btnTelefon,btnPlaystore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnWeb = findViewById(R.id.btnWeb);
        btnSms = findViewById(R.id.btnSms);
        btnHarita = findViewById(R.id.btnHarita);
        btnEmail = findViewById(R.id.btnEmail);
        btnTelefon = findViewById(R.id.btnAra);
        btnPlaystore = findViewById(R.id.btnPlayStore);

        btnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("http://serifgungor.com");
                i.setData(uri);
                startActivity(i);
            }
        });

        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("smsto:+905123488509");
                Intent i = new Intent(Intent.ACTION_SENDTO, uri);
                i.putExtra("sms_body", "The SMS text");
                startActivity(i);
            }
        });

        btnPlaystore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.facebook.katana")));
                }catch (ActivityNotFoundException e){
                    Toast.makeText(getApplicationContext(),"Hay aksi!/nBu uygulamayı açabilen program yüklü değil",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "contact@serifgungor.com" });
                intent.putExtra(Intent.EXTRA_SUBJECT, "Android Intent Örneği");
                intent.putExtra(Intent.EXTRA_TEXT, "Hocam kusura bakma, örneği deniyordum :)");
                startActivity(Intent.createChooser(intent, "E-mail gönder"));
            }
        });

        btnTelefon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("tel:+902123334499");
                i.setData(uri);
                startActivity(i);
            }
        });

        btnHarita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("geo:0,0?q=41.0085812,28.9802257 (Ayasofya)"));
                startActivity(intent);
            }
        });

    }
}
