package com.serifgungor.intentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tvAd,tvSoyad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tvAd = findViewById(R.id.tvAd);
        tvSoyad = findViewById(R.id.tvSoyad);

        String ad = getIntent().getStringExtra("ad");
        String soyad = getIntent().getStringExtra("soyad");

        tvAd.setText(ad);
        tvSoyad.setText(soyad);




    }
}
