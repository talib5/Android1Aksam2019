package com.serifgungor.intentkullanimiornek2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public void butonaTikla(View v) {

        Intent intent = new Intent(getApplicationContext(),DetayActivity.class);
        if (v.getId() == R.id.ivAjdaPekkan) {
            intent.putExtra("sanatçı","Ajda Pekkan");
            intent.putExtra("resim",R.drawable.ajdapekkan);
        } else if (v.getId() == R.id.ivMuslumGurses) {
            intent.putExtra("sanatçı","Müslüm Gürses");
            intent.putExtra("resim",R.drawable.muslum_gurses);
        } else if (v.getId() == R.id.ivSezenAksu) {
            intent.putExtra("sanatçı","Sezen Aksu");
            intent.putExtra("resim",R.drawable.sezenaksu);
        } else if (v.getId() == R.id.ivTarkan) {
            intent.putExtra("sanatçı","Tarkan");
            intent.putExtra("resim",R.drawable.tarkan);
        } else if (v.getId() == R.id.ivYildizTilbe) {
            intent.putExtra("sanatçı","Yıldız Tilbe");
            intent.putExtra("resim",R.drawable.yildiz_tilbe);
        }
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
}
