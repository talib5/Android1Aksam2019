package com.serifgungor.intentkullanimiornek2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class DetayActivity extends AppCompatActivity {

    ImageView ivDetay;
    TextView tvDetay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);

        ivDetay = findViewById(R.id.ivDetay);
        tvDetay = findViewById(R.id.tvDetay);

        String sanatci = getIntent().getStringExtra("sanatçı");
        int resimId = getIntent().getIntExtra("resim",-1);
        tvDetay.setText(sanatci);

        if(resimId!=-1){
            ivDetay.setImageResource(resimId);
        }

        this.setTitle(sanatci);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Toolbar'a geri butonu ekler

        /*
        switch (sanatci){
            case "Ajda Pekkan":
                ivDetay.setImageResource(R.drawable.ajdapekkan);
                break;
            case "Müslüm Gürses":
                ivDetay.setImageResource(R.drawable.muslum_gurses);
                break;
            case "Sezen Aksu":
                ivDetay.setImageResource(R.drawable.sezenaksu);
                break;
            case "Tarkan":
                ivDetay.setImageResource(R.drawable.tarkan);
                break;
            case "Yıldız Tilbe":
                ivDetay.setImageResource(R.drawable.yildiz_tilbe);
                break;
        }

         */

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish(); //Bulunduğum activity sayfasını kalıcı olarak kapattık.
        }
        return super.onOptionsItemSelected(item);
    }
}
