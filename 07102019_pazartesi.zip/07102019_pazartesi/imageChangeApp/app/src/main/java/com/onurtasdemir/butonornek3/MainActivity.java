package com.onurtasdemir.butonornek3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btn;
    ImageView ivResim;
    int sayi = 0;
    int[] resimler = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resimler[0] = R.drawable.img_kedi;
        resimler[1] = R.drawable.img_kopek;
        resimler[2] = R.drawable.img_panda;
        resimler[3] = R.drawable.img_zurafa;


        btn = findViewById(R.id.btnTikla);
        ivResim = findViewById(R.id.ivResim);

        ivResim.setImageResource(R.drawable.img_kedi);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivResim.setImageResource(resimler[sayi]);
                if(sayi==3){
                    sayi=0;
                }else{
                    sayi +=1;
                }


            }
        });

    }
}
